
require("dotenv").config();

const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10
});

app.get("/", (req, res) => {
    res.send("Classroom Scheduling Backend is running!");
});

app.get("/api/test-db", async (req, res) => {
    try {
        const [rows] = await db.query("SELECT COUNT(*) AS total FROM STUDENT");
        res.json({
            message: "MySQL connected successfully!",
            studentCount: rows[0].total
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Database connection failed" });
    }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
});
